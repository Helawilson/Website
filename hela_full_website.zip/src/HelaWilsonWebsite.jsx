import React from "react";
import { motion } from "framer-motion";
import { Github, Mail, Phone, Linkedin } from "lucide-react";

export default function HelaWilsonWebsite() {
  const contact = {
    name: "Hela Wilson",
    phone: "+1 (382) 889-4803",
    email: "helawilson@gmail.com",
    linkedin: "https://www.linkedin.com/in/hela-wilson-42a7b9191",
    location: "Toronto, Canada",
  };

  const summary = "Certified Software Developer with 4.6 years of experience specializing in API management, Apigee (Edge, X, Hybrid), RESTful web services, middleware integrations, and enterprise API migration projects.";

  const skills = [
    "Apigee Edge / X / Hybrid",
    "OAuth 2.0 / JWT / API Security",
    "API Design & Architecture",
    "WebMethods / Active Transfer",
    "CI/CD (Jenkins, Git, Azure DevOps)",
    "Python, JavaScript, Java",
    "Cloud: Azure, GCP basics",
    "API Testing: Postman, SOAPUI"
  ];

  return (
    <div style={{ padding: 40 }}>
      <h1>{contact.name}</h1>
      <p>{summary}</p>
      <h2>Skills</h2>
      <ul>
        {skills.map((s,i)=><li key={i}>{s}</li>)}
      </ul>
      <h2>Contact</h2>
      <p>Email: {contact.email}</p>
      <p>Phone: {contact.phone}</p>
      <p>LinkedIn: {contact.linkedin}</p>
    </div>
  );
}
