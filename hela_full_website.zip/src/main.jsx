import React from 'react'
import ReactDOM from 'react-dom/client'
import HelaWilsonWebsite from './HelaWilsonWebsite'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <HelaWilsonWebsite />
  </React.StrictMode>
)
